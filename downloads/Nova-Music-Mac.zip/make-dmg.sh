#!/bin/bash
# Run on a Mac (Terminal): ./make-dmg.sh  -> creates Nova-Music.dmg
cd "$(dirname "$0")" && chmod +x "Nova Music.app/Contents/MacOS/launcher"
hdiutil create -volname "Nova Music" -srcfolder "Nova Music.app" -ov -format UDZO Nova-Music.dmg && echo "Done: Nova-Music.dmg"
